<?php
if ($_SESSION['role_id'] == "1")
  require_once('./view/layouts/headerSinhVien.php');
if ($_SESSION['role_id'] == "2")
  require_once('./view/layouts/headerGiaoVien.php');
if ($_SESSION['role_id'] == "3")
  require_once('./view/layouts/headerDaoTao.php');
?>
<!-- Right -->
<div id="right" style="width: 100%; margin-left:10px;">
  <div class="title">Đổi mật khẩu</div>
  <div class="entry">
    <form method="POST" role="form">
      <div>
        <input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
        <input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
        <input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwULLTIwOTQ3NDQ4NjUPZBYCZg9kFggCAQ8PFgIeBFRleHQFHU5HVVnhu4ROIFRJ4bq+TiBUw4BJIChBMzY2NDMpZGQCAg8PFgIfAAUPQsOsbmggdGjGsOG7nW5nZGQCBA8WAh8ABRRDw7MgMCB0aW4gYsOhbyBt4bubaWQCBQ8WAh4LXyFJdGVtQ291bnQCAhYEZg9kFgRmDxUBD1Rvw6BuIHRyxrDhu51uZ2QCAQ8WAh8BAgMWBgIBD2QWAmYPFQIeL1RvYW5UcnVvbmcvVEtCVG9hblRydW9uZy5hc3B4I1Ro4budaSBraMOzYSBiaeG7g3UgdG/DoG4gdHLGsOG7nW5nZAICD2QWAmYPFQIlL1RvYW5UcnVvbmcvTGljaFRoaUxhaVRvYW5UcnVvbmcuYXNweCBM4buLY2ggdGhpIGzhuqFpIHRvw6BuIHRyxrDhu51uZ2QCAw9kFgJmDxUCIi9Ub2FuVHJ1b25nL0NodW9uZ1RyaW5oRGFvVGFvLmFzcHgbQ2jGsMahbmcgdHLDrG5oIMSRw6BvIHThuqFvZAIBD2QWBGYPFQEPR8OzYyBzaW5oIHZpw6puZAIBDxYCHwECChYUAgEPZBYCZg8VAiIvU2luaFZpZW4vZnJtVGhvbmdUaW5TaW5oVmllbi5hc3B4FFRow7RuZyB0aW4gY8OhIG5ow6JuZAICD2QWAmYPFQIZL0RhbmdLeUhvYy9EYW5nS2lIb2MuYXNweBDEkMSDbmcga8O9IGjhu41jZAIDD2QWAmYPFQIcL0RhbmdLeUhvYy9EYW5nS2lUaGlMYWkuYXNweBTEkMSDbmcga8O9IHRoaSBs4bqhaWQCBA9kFgJmDxUCIy9TaW5oVmllbi9UaG9pS2hvYUJpZXVTaW5oVmllbi5hc3B4E1Ro4budaSBraMOzYSBiaeG7g3VkAgUPZBYCZg8VAh5odHRwOi8vaG9jcGhpLnRoYW5nbG9uZy5lZHUudm4XUGhp4bq/dSBiw6FvIHRodSB0aeG7gW5kAgYPZBYCZg8VAh8vU2luaFZpZW4vQmFuZ0RpZW1TaW5oVmllbi5hc3B4DkLhuqNuZyDEkWnhu4NtZAIHD2QWAmYPFQIYL1NpbmhWaWVuL0xpY2hUaGlTVi5hc3B4GEzhu4tjaCB0aGkgY2jDrW5oIHRo4bupY2QCCA9kFgJmDxUCHC9TaW5oVmllbi9MaWNoVGhpRHVLaWVuLmFzcHgWTOG7i2NoIHRoaSBk4buxIGtp4bq/bmQCCQ9kFgJmDxUCIWh0dHA6Ly9zaW5odmllbi50aGFuZ2xvbmcuZWR1LnZuLxRQaGnhur91IGLDoW8gxJFp4buDbWQCCg9kFgJmDxUCIGh0dHA6Ly9zaW5odmllbi50aGFuZ2xvbmcuZWR1LnZuFUzhu4tjaCBrw70gc+G7lSBn4buRY2QYAQULY3RsMDAkYyRjcDEPEGRmBQZhMzY2NDNkGkpgLbGXsp03hZ1cjzYNmzTdpfR5xTUaEIbDFO9Aqfg=" />
      </div>

      <script type="text/javascript">
        //<![CDATA[
        var theForm = document.forms['aspnetForm'];
        if (!theForm) {
          theForm = document.aspnetForm;
        }

        function __doPostBack(eventTarget, eventArgument) {
          if (!theForm.onsubmit || theForm.onsubmit() != false) {
            theForm.__EVENTTARGET.value = eventTarget;
            theForm.__EVENTARGUMENT.value = eventArgument;
            theForm.submit();
          }
        }
        //]]>
      </script>

      <script src="/WebResource.axd?d=L8t2y_VLHccfkGlq_xnr32ySrPP0A4rG5s0fd4Ly9dYkSYrCAn5ZbRYqkIohlIUeqM19QlP2W5nbZtN16-TPwYF96ddINXHbenVBY_DKR3E1&amp;t=636935137199995647" type="text/javascript"></script>

      <script src="/WebResource.axd?d=QYfEkfSsBD2O-es6BKJQw7_e8YQbAv_gU03-B5Q83yZhkr0j5gDHaOYLcHzSwrVB4qpIneQi56I74CNG-Rc87SL8kspuwHzFaWoLZLDQJJg1&amp;t=636935137199995647" type="text/javascript"></script>
      <script type="text/javascript">
        //<![CDATA[
        function WebForm_OnSubmit() {
          if (
            typeof ValidatorOnSubmit == 'function' &&
            ValidatorOnSubmit() == false
          )
            return false;
          return true;
        }
        //]]>
      </script>

      <div>
        <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="DF1CC29B" />
        <input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAAbxqdSe4FMit5/Re9dsoOTxUZhdNxvCjgajt+wDt3DIaQKGnwVNpe6SoCSMZmnH2IZRstaeidgJjHJHJ1x7Kq8kgfO3CJUa74E+wN2qlAlAdBUKdjFxo325KMvk8uB6dcMTgXdd3ZtB1rRlx80aH2P8Zw/Xk1GsubF83G6iJ2Sfng==" />
      </div>
      <center>
        <table id="ctl00_c_cp1" cellspacing="0" cellpadding="0" border="0" style="height: 145px; border-collapse: collapse">
          <tbody>
            <tr>
              <td>
                <table border="0" cellpadding="1" cellspacing="0" style="border-collapse: collapse">
                  <tbody>
                    <tr>
                      <td>
                        <table border="0" cellpadding="0" style="height: 145px">
                          <tbody>
                            <tr>
                              <td align="center" colspan="2"></td>
                            </tr>
                            <tr>
                              <td align="right">
                                <label>Mật khẩu cũ:</label>
                              </td>
                              <td>
                                <input name="mkc" type="password" />
                              </td>
                            </tr>
                            <tr>
                              <td align="right">
                                <label>Mật khẩu mới:</label>
                              </td>
                              <td>
                                <input name="mkm" type="password" />
                              </td>
                            </tr>
                            <tr>
                              <td align="right">
                                <label>Gõ lại mật khẩu mới:</label>
                              </td>
                              <td>
                                <input name="nhaplaimk" type="password" />
                              </td>
                            </tr>
                            <tr>
                              <td align="right" colspan="3">
                                <button class="btn btn-success" name="doimk">Đổi Mật Khẩu</button>
                                <button class="btn btn-success" name="edit_sv">Thoát</button>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      </center>

      <script type="text/javascript">
        //<![CDATA[
        var Page_Validators = new Array(
          document.getElementById(
            'ctl00_c_cp1_ChangePasswordContainerID_CurrentPasswordRequired'
          ),
          document.getElementById(
            'ctl00_c_cp1_ChangePasswordContainerID_NewPasswordRequired'
          ),
          document.getElementById(
            'ctl00_c_cp1_ChangePasswordContainerID_ConfirmNewPasswordRequired'
          ),
          document.getElementById(
            'ctl00_c_cp1_ChangePasswordContainerID_NewPasswordCompare'
          )
        );
        //]]>
      </script>

      <script type="text/javascript">
        //<![CDATA[
        var ctl00_c_cp1_ChangePasswordContainerID_CurrentPasswordRequired =
          document.all ?
          document.all[
            'ctl00_c_cp1_ChangePasswordContainerID_CurrentPasswordRequired'
          ] :
          document.getElementById(
            'ctl00_c_cp1_ChangePasswordContainerID_CurrentPasswordRequired'
          );
        ctl00_c_cp1_ChangePasswordContainerID_CurrentPasswordRequired.controltovalidate =
          'ctl00_c_cp1_ChangePasswordContainerID_CurrentPassword';
        ctl00_c_cp1_ChangePasswordContainerID_CurrentPasswordRequired.errormessage =
          'Password is required.';
        ctl00_c_cp1_ChangePasswordContainerID_CurrentPasswordRequired.validationGroup =
          'ctl00$ChangePassword1';
        ctl00_c_cp1_ChangePasswordContainerID_CurrentPasswordRequired.evaluationfunction =
          'RequiredFieldValidatorEvaluateIsValid';
        ctl00_c_cp1_ChangePasswordContainerID_CurrentPasswordRequired.initialvalue =
          '';
        var ctl00_c_cp1_ChangePasswordContainerID_NewPasswordRequired =
          document.all ?
          document.all[
            'ctl00_c_cp1_ChangePasswordContainerID_NewPasswordRequired'
          ] :
          document.getElementById(
            'ctl00_c_cp1_ChangePasswordContainerID_NewPasswordRequired'
          );
        ctl00_c_cp1_ChangePasswordContainerID_NewPasswordRequired.controltovalidate =
          'ctl00_c_cp1_ChangePasswordContainerID_NewPassword';
        ctl00_c_cp1_ChangePasswordContainerID_NewPasswordRequired.errormessage =
          'New Password is required.';
        ctl00_c_cp1_ChangePasswordContainerID_NewPasswordRequired.validationGroup =
          'ctl00$ChangePassword1';
        ctl00_c_cp1_ChangePasswordContainerID_NewPasswordRequired.evaluationfunction =
          'RequiredFieldValidatorEvaluateIsValid';
        ctl00_c_cp1_ChangePasswordContainerID_NewPasswordRequired.initialvalue =
          '';
        var ctl00_c_cp1_ChangePasswordContainerID_ConfirmNewPasswordRequired =
          document.all ?
          document.all[
            'ctl00_c_cp1_ChangePasswordContainerID_ConfirmNewPasswordRequired'
          ] :
          document.getElementById(
            'ctl00_c_cp1_ChangePasswordContainerID_ConfirmNewPasswordRequired'
          );
        ctl00_c_cp1_ChangePasswordContainerID_ConfirmNewPasswordRequired.controltovalidate =
          'ctl00_c_cp1_ChangePasswordContainerID_ConfirmNewPassword';
        ctl00_c_cp1_ChangePasswordContainerID_ConfirmNewPasswordRequired.errormessage =
          'Confirm New Password is required.';
        ctl00_c_cp1_ChangePasswordContainerID_ConfirmNewPasswordRequired.validationGroup =
          'ctl00$ChangePassword1';
        ctl00_c_cp1_ChangePasswordContainerID_ConfirmNewPasswordRequired.evaluationfunction =
          'RequiredFieldValidatorEvaluateIsValid';
        ctl00_c_cp1_ChangePasswordContainerID_ConfirmNewPasswordRequired.initialvalue =
          '';
        var ctl00_c_cp1_ChangePasswordContainerID_NewPasswordCompare =
          document.all ?
          document.all[
            'ctl00_c_cp1_ChangePasswordContainerID_NewPasswordCompare'
          ] :
          document.getElementById(
            'ctl00_c_cp1_ChangePasswordContainerID_NewPasswordCompare'
          );
        ctl00_c_cp1_ChangePasswordContainerID_NewPasswordCompare.controltovalidate =
          'ctl00_c_cp1_ChangePasswordContainerID_ConfirmNewPassword';
        ctl00_c_cp1_ChangePasswordContainerID_NewPasswordCompare.errormessage =
          'Gõ lại mật khẩu không chính xác';
        ctl00_c_cp1_ChangePasswordContainerID_NewPasswordCompare.display =
          'Dynamic';
        ctl00_c_cp1_ChangePasswordContainerID_NewPasswordCompare.validationGroup =
          'ctl00$ChangePassword1';
        ctl00_c_cp1_ChangePasswordContainerID_NewPasswordCompare.evaluationfunction =
          'CompareValidatorEvaluateIsValid';
        ctl00_c_cp1_ChangePasswordContainerID_NewPasswordCompare.controltocompare =
          'ctl00_c_cp1_ChangePasswordContainerID_NewPassword';
        ctl00_c_cp1_ChangePasswordContainerID_NewPasswordCompare.controlhookup =
          'ctl00_c_cp1_ChangePasswordContainerID_NewPassword';
        //]]>
      </script>

      <script type="text/javascript">
        //<![CDATA[

        var Page_ValidationActive = false;
        if (typeof ValidatorOnLoad == 'function') {
          ValidatorOnLoad();
        }

        function ValidatorOnSubmit() {
          if (Page_ValidationActive) {
            return ValidatorCommonOnSubmit();
          } else {
            return true;
          }
        }
        //]]>
      </script>
    </form>
  </div>
</div>

<!-- End Right -->
</div>
<!-- End Page -->
<!-- Footer -->
</body>

</html>