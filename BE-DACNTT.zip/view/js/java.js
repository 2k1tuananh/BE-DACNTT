function LoadForm(id) {
  window.location = id;
}
